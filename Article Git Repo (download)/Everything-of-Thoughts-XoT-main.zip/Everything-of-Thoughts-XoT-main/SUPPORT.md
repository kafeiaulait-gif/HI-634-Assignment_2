# Support

## How to file issues and get help  

This project uses GitHub Issues to track bugs and feature requests. Please search the existing 
issues before filing new issues to avoid duplicates.  For new issues, file your bug or 
feature request as a new Issue.

For help and questions about using this project, please contact us at rmding@gatech.edu or simply open an issue. Thank you!



## Microsoft Support Policy  

Support for this **PROJECT or PRODUCT** is limited to the resources listed above.